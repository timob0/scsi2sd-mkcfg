// stdafx.cpp : source file that includes just the standard includes
//	XGetoptTest.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information
#ifdef __WIN__

#include "stdafx.h"



#endif