#ifndef _OUTPUTFORMATTYPE_H
#define _OUTPUTFORMATTYPE_H

enum OutputFormatType { Default, Json };

#endif