Fatcat source code
==================

The code is splitted into directories:

* `core/` the core of FAT to access the filesystem, its tables
  and its entries
* `table/` tools to deal with the file allocation tables
* `analysis/` analysis tools

